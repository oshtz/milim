# @oshtz/shatz-avatars

Dependency-free deterministic atmospheric SVG avatars for the web.

## Use in another local project

```powershell
npm run check
npm pack
```

Install the generated `.tgz` from the consuming project:

```powershell
npm install D:\DEV\components\shatz-avatars\oshtz-shatz-avatars-0.1.0.tgz
```

Register the native element once, then use it from HTML or any framework:

```ts
import { defineShatzAvatar } from '@oshtz/shatz-avatars';

defineShatzAvatar();
```

```html
<shatz-avatar
  seed="omer"
  shape="circle"
  texture="grain"
  color="#ff8069"
  secondary-color="#8849b8"
  background="#f7d6a8"
></shatz-avatar>
```

The element also accepts `blur`, `noise`, `dither`, `dither-strength`, `overlay-gradient`, `overlay-opacity`, `overlay-fade`, `overlay-dither-strength`, `size`, and `title`. Use `dither="false"` or `overlay-gradient="false"` to disable default-on features.

For direct or server-rendered output:

```ts
import { createAvatarSvg } from '@oshtz/shatz-avatars';

container.innerHTML = createAvatarSvg({ seed: 'omer', size: 64 });
```

Defaults: Grain, Blur 90, Noise 100, Dither 100, Overlay 70%, Overlay fade 40%, and Overlay dither 100. The fixed 100×100 filter raster keeps thumbnail and enlarged dither geometry identical.
